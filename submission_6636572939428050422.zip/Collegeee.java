import java.util.*;
import java.lang.*;
class Collegeee {
  public static void main(String[] args) {
    ArrayList<Double> a1 = new ArrayList<Double>();
    Scanner sc = new Scanner(System.in);
    double num = sc.nextDouble();
    for(int i=0;i<num;i++)
      {
        a1.add(sc.nextDouble());
      }
    
    Collections.sort(a1);

    
      double temp =0;
      double val = 0;
      double ans = 0;
      for(int j=0;j<num;j++)
      {
        val = a1.get(j)*(num-j);
        if(val>temp)
        {
          temp = val;
          ans = a1.get(j);
        }
      }
    temp = Math.round(temp);
    ans = Math.round(ans);
    System.out.println(temp + " " + ans);
  }
}
      
