import java.util.*;
class College {
  public static void main(String[] args) {
    ArrayList<Integer> a1 = new ArrayList<Integer>();
    Scanner sc = new Scanner(System.in);
    int num = sc.nextInt();
    for(int i=0;i<num;i++)
      {
        a1.add(sc.nextInt());
      }
    
    Collections.sort(a1);

    
      int temp =0;
      int val = 0;
      int ans = 0;
      for(int j=0;j<num;j++)
      {
        val = a1.get(j)*(num-j);
        if(val>temp)
        {
          temp = val;
          ans = a1.get(j);
        }
      }
    System.out.println(temp + " " + ans);
  }
}
      
